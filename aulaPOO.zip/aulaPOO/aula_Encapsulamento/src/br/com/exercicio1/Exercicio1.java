package br.com.exercicio1;

public class Exercicio1 {
	public static void main(String[] args) {
	Pessoa pessoa = new Pessoa("Felipe", 20, "felipegoulart557@gmail.com");
	System.out.println("Nome: " + pessoa.getNome() + " Idade: " + pessoa.getIdade() + " Email: " + pessoa.getEmail());
	}
}