package br.com.exercicio3;

public class Retangulo {
	
	private int base;
	private int altura;
	
	public Retangulo(int base, int altura) {
		this.altura = altura;
		this.base = base;
		
		if(base <= 0) {
			base = 1;
		}
		if(altura <= 0) {
			altura = 1;
		}
		
	}
	
	public int getBase() {
		return base;
	}
	
	public int getAltura() {
		return altura;
	}
	
	public int calcularArea() {
		int area = this.base * this.altura;
		return area;
	}
	
	public int calcularPerimetro() {
		int perimetro = this.base * 2 * this.altura * 2;
		return perimetro;
	}
	
	
}