package br.com.exercicio3;

public class Exercicio3 {
	public static void main(String[] args) {
		Retangulo retangulo = new Retangulo(5, 5);
		System.out.println("A área é: " + retangulo.calcularArea() + " O perimetro é: " + retangulo.calcularPerimetro());
	}

}