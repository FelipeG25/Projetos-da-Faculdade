package br.com.exercicio4;

public class Exercicio4 {
	public static void main(String[] args) {
	Aluno aluno = new Aluno("Felipe Goulart", 2528, "Ánalise e Desenvolvimento de Sistemas", 9);
	System.out.println("Nome: " + aluno.getNome() + " Matrícula: " + aluno.getMatricula() + " Curso: " + aluno.getCurso() + " Nota: " + aluno.getNota());
	}
}