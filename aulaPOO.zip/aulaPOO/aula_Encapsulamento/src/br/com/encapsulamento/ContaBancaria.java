package br.com.encapsulamento;

public class ContaBancaria {
	//Atributo privado
	private double saldo;
	
	//Método público para acessar o atributo
	public double getSaldo() {
		return saldo;
	}
	public void depositar(double valor) {
		saldo += valor;
	}
}
