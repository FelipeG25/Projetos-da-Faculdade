package br.com.encapsulamento;

public class Aula {
	public static void main(String[] args) {
		ContaBancaria conta = new ContaBancaria();
		
		conta.depositar(500.0);
		double saldoAtual = conta.getSaldo();
		System.out.println("Saldo atual: " + saldoAtual);
	}
}
