package br.com.exercicio5;

public class Exercicio5 {
	public static void main(String[] args) {
	Carro carro = new Carro("Ford", "Ford GT", 2022);
	System.out.println("Marca: " + carro.getMarca() + " Modelo: " + carro.getModelo() + " Ano: " + carro.getAno());
	}
}