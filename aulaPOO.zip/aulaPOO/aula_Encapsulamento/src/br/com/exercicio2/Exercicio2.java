package br.com.exercicio2;

public class Exercicio2 {

	public static void main(String[] args) {
	Livro livro = new Livro("Jujutsu Kaisen", "Gege Akutami", 2018);
	System.out.println("Titulo: " + livro.getTitulo() + " Autor: " + livro.getAutor() + " Ano de publicação: " + livro.getAnoPublicacao());
	}
}