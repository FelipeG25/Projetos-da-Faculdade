/**
 * 
 */
/**
 * @author felipe_goulart1
 *
 */
module aula_Encapsulamento {
}